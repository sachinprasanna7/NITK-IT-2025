/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <algorithm>

using namespace std;

void bubbleSort(int arr[], int n){      //BubbleSort algorithm to sort the array

    for (int i = 0; i < n - 1; i++){
        for (int j = 0; j < n-i-1; j++){
            if (arr[j]>arr[j+1])
                swap(arr[j], arr[j + 1]);
        }
    }
}


int linearSearch(int arr[],int temp_array[],int n){
    

    bubbleSort(arr,n);              //Have to sort array to find median of array
    int median_element = arr[49];    //Since the median of the array is the the middle element
    
    cout<<"Median element is "<<median_element<<endl;
    
    
    for (int i=0;i<n;i++){
        
        cout<<"Comparing "<<median_element<<" and "<<temp_array[i]<<" at index "<<i<<endl;
        
        if(median_element==temp_array[i]){
            cout<<endl<<"Median element is found in intial array at index: "<<i<<endl;
            return i;
        }
        
    }  
    return -1;     //If median element is not found

}


int binarySearch(int arr[], int n){
    
    bubbleSort(arr,n);     //Sorting the array as BinarySearch works on sorted array
    int median_element = arr[49];    //Since the median of the array is the 49th index element
    
    cout<<"Median element is "<<median_element<<endl<<endl;
    
    int start = 0;
    int end = n-1;
    
    int mid = (start + end)/2;
    
    while(start<end){
        
        cout<<endl<<"BINARY SEARCH"<<endl;
        cout<<"Comparing "<<arr[mid]<<" and "<<median_element<<endl;
        cout<<"The mid element is: "<<arr[mid]<<endl;
        
        if(median_element==arr[mid]){
            return arr[mid];
        }
        else if(median_element<arr[mid]){
            end = mid - 1;
        }
        else{
            start = mid+1;
        }
        
        mid = (start + end)/2;
    }
    
    return -1;  //If median element is not found, return -1
}




int main(){
    
    int arr[100];
    int temp_array[100];
    
    for(int i = 0; i<100; i++){
        arr[i]=(rand()%100)+1;      //Using rand function to generate random numbers between 1 to 100 and store in array
    }
   
    for(int i=0;i<100;i++){
        temp_array[i]=arr[i];     //Creating another array to use for linear Search
    }
    
    int lin_search = linearSearch(arr,temp_array,100);
    cout<<endl<<"The median element is found at index "<<lin_search<<" by Linear Search";
    
    cout<<endl<<endl;
    int bin_search = binarySearch(arr,100);
    cout<<"The median Element found by Binary Search is: "<<bin_search;
    
    
    
    return 0;
}