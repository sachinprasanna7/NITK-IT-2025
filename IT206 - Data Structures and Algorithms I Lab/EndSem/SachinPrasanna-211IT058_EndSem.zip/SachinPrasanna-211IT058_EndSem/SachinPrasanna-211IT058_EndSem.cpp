/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <ctime>

using namespace std;

class Node{
    public:
    int data;
    Node* right;
    Node* left;
    
    Node(int data){
        this -> data = data;
        this -> right = nullptr;
        this -> left = nullptr;
    }
};

//Function to construct the tree

Node* Insert(Node* root, int data){

    if(root == nullptr){
        root = new Node(data);
        return root;
    }

    if(root -> data < data) 
        root -> right = Insert(root->right, data);

    else if(root -> data > data) 
        root -> left = Insert(root->left, data);
    
    return root;
    
}


//FUNCTIONS TO FIND INORDER SUCCESSOR

//METHOD 1, THROUGH ARRAYS  (100% working)

int inorderArray[20];
int index = 0;

void inorder(Node* root){
    if(root == nullptr) return;
    
    inorder(root->left);
    cout<<root->data<<"  ";
    inorderArray[index++] = root -> data;
    inorder(root->right);
}

//FUnction to make sure distinct integers are stored in the array

bool isFound(int arr[], int num, int t){
    
    for(int i = 0 ; i < t ; i++){
        if(num == arr[i]) return true;
    }
    return false;
}


// METHOD 2, THROUGH TREES (Cetain edge cases did not work)

// int findMinimumElement(Node* root){
//     Node* temp = root;
//     while(temp -> left != nullptr){
//         temp = temp -> left;
//     }
    
//     return temp -> data;
// }

// int inorderSuccessor(Node* &root, int val){
    
//     int ans = root -> data;
//     Node* temp = root;
    
//     while(temp != nullptr){
    
//         if(temp -> data == val){
//             if(temp -> right == nullptr) return ans;
//             return findMinimumElement(temp -> right);
//         }
        
//         else if(temp -> data < val){
//             ans = temp -> data;
//             temp = temp -> right;
//         }
        
//         else{
//             ans = temp -> data;
//             temp = temp -> left;
//         }
//     }
    
//     return -1;
// }



int main()
{
    srand(time(nullptr));
    
    Node* root = nullptr;
    
    //Generating random distinct integers in the given range and storing them in an array arr
    int arr[20];
    int t = 1;
    
    arr[0] = rand() % 50;
    
    do{
        int num = rand() % 50;
        if(!isFound(arr,num,t)){
            arr[t++] = num;
        }
        
    }while(t < 20);
    
    //Printing the randomly generated integers
    cout<<"The randomly generated integers are:\n\n";
    for(int i = 0 ; i < 20; i++){
        cout<<arr[i]<<"  ";
    }
    
    cout<<endl;
    
    //Constructing the tree
    
    for(int i = 0 ; i < 20 ; i++){
        root = Insert(root,arr[i]);
    }
    
    cout<<"\n\nThe inorder traversal of the constructed tree is as follows:\n\n";
    
    //Printing inorder traversal
    inorder(root);
    
    //A loop running 3 times to find inorder successor of the entered element and printing it
    
    for(int j = 0 ; j < 3 ; j++){
        int val;
        cout<<"\n\nEnter the number you want the inorder successor of: ";
        cin>>val;
        
        // cout<<"The inorder Successor of "<<val<<" is: "<<inorderSuccessor(root, val);
        
        bool flag = false;
        int i = 0;
        for(; i < 19 ; i++){
            if(inorderArray[i] == val){
                cout<<"\nInorder successor of "<<val<<" is: "<<inorderArray[i+1];
                flag = true;
            }
        }

        
        if(val == inorderArray[i]){
            cout<<"\n"<<val<<" does not have an inorder successor as it is the largest element in the tree";
            flag = true;
        }
        
        else if(!flag){
            cout<<"\n"<<val<<" is not present in the tree, so there is no inorder successor";
        }
        
    }
    
    return 0;
}